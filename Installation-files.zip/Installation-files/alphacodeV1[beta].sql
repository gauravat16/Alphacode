-- MySQL dump 10.13  Distrib 5.7.12, for Linux (x86_64)
--
-- Host: localhost    Database: CodeSalad
-- ------------------------------------------------------
-- Server version	5.7.12-0ubuntu1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Competitions`
--

DROP TABLE IF EXISTS `Competitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Competitions` (
  `compId` int(11) NOT NULL AUTO_INCREMENT,
  `compName` varchar(255) DEFAULT NULL,
  `compUsers` longtext,
  `compDate` varchar(45) DEFAULT NULL,
  `compAuthor` varchar(45) DEFAULT NULL,
  `CompFileLocation` varchar(255) DEFAULT NULL,
  `CompPId` longtext,
  `CompCreation` varchar(255) DEFAULT NULL,
  `CompDuration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`compId`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Competitions`
--

LOCK TABLES `Competitions` WRITE;
/*!40000 ALTER TABLE `Competitions` DISABLE KEYS */;
INSERT INTO `Competitions` VALUES (1,'test','test','test','test','test','test',NULL,NULL),(2,'BEta',NULL,'2016-04-30 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/2/info.txt',NULL,NULL,NULL),(3,'dcfvgbjhnkjmk,l',NULL,'2016-05-10 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/3/info.txt',NULL,'2016-04-30 ',NULL),(4,'standard dummy text ','55,rahul@morena.com,rahul@morena.com,rahul@morena.com,,,,,,,,,,,,,,,,,,,,,,,,rahul@morena.com,rahul@morena.com,rahul@morena.com,rahul@morena.com,bandil@komal.com,bandil@komal.com,bandil@komal.com,bandil@komal.com,','2016-05-28 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/4/info.txt','63,55,67,78,79,','2016-04-30 ',NULL),(5,'The Mega Competion',NULL,'2016-05-10 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/5/info.txt',NULL,'2016-05-01','1:2:0'),(6,'test',NULL,'2016-05-19 ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/6/info.txt',NULL,'2016-05-01','5:6:00'),(7,'',NULL,' ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/7/info.txt',NULL,'2016-05-01',''),(8,'',NULL,' ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/8/info.txt',NULL,'2016-05-01',''),(9,'addProb','rahul@morena.com,','2016-05-25 ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/9/info.txt',NULL,'2016-05-01','5:6:00'),(10,'newComp','rahul@morena.com,','2016-06-10 ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/10/info.txt',NULL,'2016-05-01','5:6:00'),(11,'newComp',NULL,'2016-05-13 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/11/info.txt',NULL,'2016-05-01','5:6:00'),(12,'pass','rahul@morena.com,rahul@morena.com,','2016-05-26 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/12/info.txt',NULL,'2016-05-01','5:6:00'),(13,'newComp','rahul@morena.com,','2016-05-11 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/13/info.txt',NULL,'2016-05-01','5:6:00'),(14,'isfromComp','rahul@morena.com,bandil@komal.com,bandil@komal.com,','2016-05-12 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/14/info.txt',NULL,'2016-05-01','5:6:00'),(15,'/Web/NewProblem.jsp','rahul@morena.com,rahul@morena.com,','2016-05-12 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/15/info.txt',NULL,'2016-05-01','5:6:00'),(16,'/Web/NewProblem.jsp','rahul@morena.com,','2016-05-12 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/16/info.txt',NULL,'2016-05-01','5:6:00'),(17,'compIddbfgh',NULL,'2016-05-25 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/17/info.txt',NULL,'2016-05-01','5:6:00'),(18,'asdgfghj',NULL,'2016-05-18 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/18/info.txt',NULL,'2016-05-01','5:6:00'),(19,'dfghjk',NULL,'2016-05-14 ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/19/info.txt',NULL,'2016-05-01','4'),(20,'',NULL,' ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/20/info.txt',NULL,'2016-05-01',''),(21,'dsf',NULL,'2016-05-21 ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/21/info.txt',NULL,'2016-05-01','5:6:00'),(22,' April LoC Competitive Programming Marathon','rahul@morena.com,rahul@morena.com,bandil@komal.com,','2016-05-12 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/22/info.txt',NULL,'2016-05-01','5:6:00'),(23,'Aencode',NULL,'2016-05-17 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/23/info.txt',NULL,'2016-05-01','5:6:00'),(24,'fdgfh jkjl','rahul@morena.com,','2016-05-27 ','rashmi@gmail.com','/home/gaurav/CodeSalad/Competitions/24/info.txt',NULL,'2016-05-17','5:6:00'),(25,'',NULL,'2016-05-27 ','bandil@komal.com','/home/gaurav/CodeSalad/Competitions/25/info.txt',NULL,'2016-05-18',''),(26,'dsfcgjkl.;','rahul@morena.com,','2016-05-12 ','rahul@morena.com','/home/gaurav/CodeSalad/Competitions/26/info.txt',NULL,'2016-05-25','5:6:00'),(27,'sdfghjk',NULL,'2016-05-04 ','bandil@komal.com','/home/gaurav/CodeSalad/Competitions/27/info.txt',NULL,'2016-05-29','5:8:9');
/*!40000 ALTER TABLE `Competitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Problems`
--

DROP TABLE IF EXISTS `Problems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Problems` (
  `ProbId` int(255) NOT NULL AUTO_INCREMENT,
  `Pname` varchar(45) DEFAULT NULL,
  `CreatedBy` varchar(45) DEFAULT NULL,
  `CreatedOn` varchar(45) DEFAULT NULL,
  `MaxTime` varchar(45) DEFAULT NULL,
  `MaxMemory` varchar(45) DEFAULT NULL,
  `Difficulty` varchar(45) NOT NULL,
  `FromComp` varchar(45) NOT NULL,
  PRIMARY KEY (`ProbId`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Problems`
--

LOCK TABLES `Problems` WRITE;
/*!40000 ALTER TABLE `Problems` DISABLE KEYS */;
INSERT INTO `Problems` VALUES (1,'sss','ssss','now','','','easy',''),(2,'sss','ssss','now','','','easy',''),(3,'sss','ssss','now','','','easy',''),(4,'da','Gaurav Sharma ','02:05:21',' ',' ','E',''),(5,'aad sdfs af sfs effes s sfs ','Gaurav Sharma ','02:06:42',' ',' ','E',''),(6,'Test problem','Gaurav Sharma ','00:06:39',' ',' ','M',''),(7,'Test problem','Gaurav Sharma ','00:08:33',' ',' ','M',''),(8,'Test','Gaurav Sharma ','00:09:37',' ',' ','H',''),(9,'hjjb','Gaurav Sharma ','00:19:34',' ',' ','H',''),(10,'test prob','Gaurav Sharma ','00:44:44',' ',' ','M',''),(11,'\r\nCiel and A-B Problem','Gaurav Sharma ','22:00:50',' ',' ','E',''),(12,'Life, the Universe, and Everything','Gaurav Sharma ','21:39:58',' ',' ','B',''),(13,'Life, the Universe, and Everything','Gaurav Sharma ','21:40:10',' ',' ','B',''),(14,'Life, the Universe, and Everything','Gaurav Sharma ','21:40:22',' ',' ','B',''),(15,'test','Gaurav Sharma ','22:26:18',' ',' ','B',''),(16,'vvvv','Devesh Dubey ','22:28:58',' ',' ','B',''),(17,'dfghj','Devesh Dubey ','22:32:52',' ',' ','B',''),(18,'dsfghjk','Gaurav Sharma ','01:37:47',' ',' ','M',''),(19,'DSFG','Gaurav Sharma ','01:42:35',' ',' ','B',''),(20,'DSFG','Gaurav Sharma ','01:44:56',' ',' ','B',''),(21,'bn','Gaurav Sharma ','01:45:54',' ',' ','B',''),(22,'dddd','Gaurav Sharma ','01:47:15',' ',' ','B',''),(23,'tryhjk','Gaurav Sharma ','01:49:59',' ',' ','H',''),(24,'Program to print lol','rashmi ','23:13:07',' ',' ','B',''),(25,'print whatever value is entered.','rashmi ','00:16:15',' ',' ','B',''),(26,'Date test','rashmi ','1970/01/01 05:30:00',' ',' ','B',''),(27,'test','rashmi ','SystemClock[Z]',' ',' ','E',''),(28,'Zoom','Barry Allen ','2016-04-21',' ',' ','B',''),(29,'Print lol once','Rashmi Sharma ','2016-04-24',' ',' ','B',''),(30,'print value entered','Rashmi Sharma ','2016-04-24',' ',' ','B',''),(31,'Print factorial of a number','Rashmi Sharma ','2016-04-25',' ',' ','B',''),(32,'Cleaning Up','neha@yahoo.com ','2016-04-25',' ',' ','B',''),(33,'Its a hard problem','neha@yahoo.com ','2016-04-25',' ',' ','H',''),(34,'this is a test','rashmi@gmail.com ','2016-04-25',' ',' ','H',''),(35,'','rashmi@gmail.com ','2016-04-25',' ',' ','B',''),(36,'Palindrone','rashmi@gmail.com ','2016-04-26',' ',' ','B',''),(37,'hello','rashmi@gmail.com ','2016-04-26',' ',' ','B',''),(38,'bchbd','rashmi@gmail.com ','2016-04-26',' ',' ','B',''),(39,'Solve Me First','rahul@morena.com ','2016-04-29',' ',' ','B',''),(40,'newComp','rashmi@gmail.com ','2016-05-01',' ',' ','H',''),(41,'/Web/NewProblem.jsp','rashmi@gmail.com ','2016-05-01',' ',' ','B',''),(42,'srdcfgjj','rashmi@gmail.com ','2016-05-01',' ',' ','B',''),(43,'sdfghjkl','rashmi@gmail.com ','2016-05-01',' ',' ','B',''),(44,'sdfghjk','rashmi@gmail.com ','2016-05-01',' ',' ','M',''),(45,'rxdctfvgbhnjkml','rashmi@gmail.com ','2016-05-01',' ',' ','M',''),(46,'rxdctfvgbhnjkml','rashmi@gmail.com ','2016-05-01',' ',' ','M',''),(47,'fghjkl','rahul@morena.com ','2016-05-01',' ',' ','M',''),(48,'wdfghj','rahul@morena.com ','2016-05-01',' ',' ','H',''),(49,'dgfghjkj','rahul@morena.com ','2016-05-01',' ',' ','B',''),(50,'fgg','rashmi@gmail.com ','2016-05-01',' ',' ','M',''),(51,'Life universe','bandil@komal.com ','2016-05-01',' ',' ','B',''),(52,'Life universe','bandil@komal.com ','2016-05-01',' ',' ','B',''),(53,'Life universe','bandil@komal.com ','2016-05-01',' ',' ','B',''),(54,'Life','bandil@komal.com ','2016-05-01',' ',' ','E',''),(55,'er','bandil@komal.com ','2016-05-01',' ',' ','B',''),(56,'dfhghkjl','bandil@komal.com ','2016-05-01',' ',' ','M',''),(57,'xfghjk','bandil@komal.com ','2016-05-01',' ',' ','M',''),(58,'htgvrf','rahul@morena.com ','2016-05-25',' ',' ','B','0'),(59,'tr','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(60,'jbgnhbb','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(61,'fdfdf','rahul@morena.com ','2016-05-25',' ',' ','H','1'),(62,'gggg','rahul@morena.com ','2016-05-25',' ',' ','H','1'),(63,'sfsdf','rahul@morena.com ','2016-05-25',' ',' ','M','1'),(64,'df','rahul@morena.com ','2016-05-25',' ',' ','H','1'),(65,'d','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(66,'dsd','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(67,'dfxgfh','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(68,'mn','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(69,'nb ','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(70,'nm','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(71,'nm','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(72,'mn','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(73,'mn','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(74,'bn','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(75,'qweertyyuio','rahul@morena.com ','2016-05-25',' ',' ','B','0'),(76,',,.','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(77,'hj','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(78,'s','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(79,'hj','rahul@morena.com ','2016-05-25',' ',' ','B','1'),(80,'sd','rahul@morena.com ','2016-05-28',' ',' ','E','0'),(81,'cgfhj','rahul@morena.com ','2016-05-28',' ',' ','B','0'),(82,'sdsd','rahul@morena.com ','2016-05-28',' ',' ','B','0'),(83,'as','rahul@morena.com ','2016-05-28',' ',' ','B','0');
/*!40000 ALTER TABLE `Problems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Solutions`
--

DROP TABLE IF EXISTS `Solutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Solutions` (
  `Uname` varchar(45) NOT NULL,
  `ProbId` varchar(45) NOT NULL,
  `Status` varchar(45) DEFAULT NULL,
  `ExecTime` varchar(45) DEFAULT NULL,
  `ExecMem` varchar(45) DEFAULT NULL,
  `SubmittedOn` varchar(45) DEFAULT NULL,
  `LangUsed` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Solutions`
--

LOCK TABLES `Solutions` WRITE;
/*!40000 ALTER TABLE `Solutions` DISABLE KEYS */;
INSERT INTO `Solutions` VALUES ('test','test','test','test','test','test',''),('rashmi@gmail.com','12','CE','','','2016-04-21','java'),('rashmi@gmail.com','12','CE','','','2016-04-21','java'),('rashmi@gmail.com','12','CE','','','2016-04-21','java'),('rashmi@gmail.com','12','CE','','','2016-04-21','java'),('rashmi@gmail.com','12','CE','','','2016-04-21','java'),('rashmi@gmail.com','12','CE','','','2016-04-21','java'),('rashmi@gmail.com','13','CE','','','2016-04-21','java'),('rashmi@gmail.com','12','CE','','','2016-04-21','java'),('rashmi@gmail.com','25','CA','','','2016-04-22','java'),('rashmi@gmail.com','25','CE','','','2016-04-22','java'),('rashmi@gmail.com','25','CA','','','2016-04-22','java'),('rashmi@gmail.com','20','WA','','','2016-04-22','java'),('rashmi@gmail.com','25','CA','','','2016-04-22','java'),('rashmi@gmail.com','25','CA','','','2016-04-23','java'),('rashmi@gmail.com','25','CA','','','2016-04-23','java'),('rashmi@gmail.com','25','CE','','','2016-04-23','java'),('rashmi@gmail.com','25','CA','','','2016-04-23','java'),('rashmi@gmail.com','25','CA','','','2016-04-23','java'),('rashmi@gmail.com','25','WA','','','2016-04-23','java'),('rashmi@gmail.com','25','WA','','','2016-04-23','java'),('rashmi@gmail.com','29','CA','','','2016-04-24','java'),('rashmi@gmail.com','29','WA','','','2016-04-24','java'),('rashmi@gmail.com','30','CE','','','2016-04-24','c'),('rashmi@gmail.com','30','CE','','','2016-04-24','java'),('rashmi@gmail.com','30','CE','','','2016-04-24','java'),('rashmi@gmail.com','30','WA','','','2016-04-24','c'),('rashmi@gmail.com','30','WA','','','2016-04-24','c'),('rashmi@gmail.com','30','CA','','','2016-04-24','c'),('rashmi@gmail.com','30','CE','','','2016-04-24','c'),('rashmi@gmail.com','30','WA','','','2016-04-24','c'),('rashmi@gmail.com','30','CA','','','2016-04-24','c'),('rashmi@gmail.com','30','CA','','','2016-04-24','c'),('rashmi@gmail.com','12','CE','','','2016-04-25','c'),('rashmi@gmail.com','12','CE','','','2016-04-25','java'),('rashmi@gmail.com','29','CE','','','2016-04-25','c'),('rashmi@gmail.com','25','CE','','','2016-04-25','java'),('rashmi@gmail.com','12','CE','','','2016-04-25','java'),('rashmi@gmail.com','12','CE','','','2016-04-25','c'),('rashmi@gmail.com','31','CE','','','2016-04-25','cpp'),('rashmi@gmail.com','31','CA','','','2016-04-25','cpp'),('rashmi@gmail.com','31','WA','','','2016-04-25','cpp'),('rashmi@gmail.com','31','CE','','','2016-04-25','c'),('rashmi@gmail.com','31','CE','','','2016-04-25','c'),('rashmi@gmail.com','31','CE','','','2016-04-25','java'),('rashmi@gmail.com','31','CA','','','2016-04-25','cpp'),('rashmi@gmail.com','24','CE','','','2016-04-25','java'),('rashmi@gmail.com','24','CA','','','2016-04-25','cpp'),('rashmi@gmail.com','24','WA','','','2016-04-25','cpp'),('neha@yahoo.com','29','CA','','','2016-04-25','cpp'),('neha@yahoo.com','24','CE','','','2016-04-25','cpp'),('neha@yahoo.com','24','CE','','','2016-04-25','java'),('neha@yahoo.com','7','WA','','','2016-04-25','java'),('rashmi@gmail.com','12','CE','','','2016-04-25','cpp'),('neha@yahoo.com','11','CE','','','2016-04-25','cpp'),('rashmi@gmail.com','12','CE','','','2016-04-26','c'),('rashmi@gmail.com','36','WA','','','2016-04-26','java'),('rashmi@gmail.com','38','WA','','','2016-04-26','java'),('rashmi@gmail.com','31','CE','','','2016-04-26','cpp'),('rashmi@gmail.com','30','CE','','','2016-04-27','java'),('rashmi@gmail.com','30','CE','','','2016-04-27','c'),('rashmi@gmail.com','13','CE','','','2016-04-27','java'),('rashmi@gmail.com','29','WA','','','2016-04-29','java'),('rashmi@gmail.com','31','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','31','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','31','CA','','','2016-04-29','cpp'),('rashmi@gmail.com','31','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','31','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','31','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','31','CE','','','2016-04-29','java'),('rashmi@gmail.com','31','CE','','','2016-04-29','java'),('neha@yahoo.com','31','CE','','','2016-04-29','cpp'),('neha@yahoo.com','31','CE','','','2016-04-29','java'),('neha@yahoo.com','31','CE','','','2016-04-29','java'),('neha@yahoo.com','31','CE','','','2016-04-29','java'),('neha@yahoo.com','31','CE','','','2016-04-29','cpp'),('neha@yahoo.com','32','CE','','','2016-04-29','java'),('neha@yahoo.com','32','CE','','','2016-04-29','cpp'),('neha@yahoo.com','32','CE','','','2016-04-29','java'),('neha@yahoo.com','32','CE','','','2016-04-29','java'),('neha@yahoo.com','32','CE','','','2016-04-29','c'),('neha@yahoo.com','32','CE','','','2016-04-29','c'),('neha@yahoo.com','32','WA','','','2016-04-29','java'),('neha@yahoo.com','32','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','12','CE','','','2016-04-29','java'),('rashmi@gmail.com','29','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','29','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','29','CE','','','2016-04-29','cpp'),('rashmi@gmail.com','29','CA','','','2016-04-29','cpp'),('rashmi@gmail.com','29','WA','','','2016-04-29','cpp'),('rashmi@gmail.com','29','CA','','','2016-04-29','cpp'),('rashmi@gmail.com','29','WA','','','2016-04-29','cpp'),('rashmi@gmail.com','29','CA','','','2016-04-29','java'),('rashmi@gmail.com','29','WA','','','2016-04-29','java'),('rashmi@gmail.com','29','CA','','','2016-04-29','cpp'),('neha@yahoo.com','29','CE','','','2016-04-29','cpp'),('neha@yahoo.com','29','CA','','','2016-04-29','cpp'),('neha@yahoo.com','29','CE','','','2016-04-29','c'),('neha@yahoo.com','29','CE','','','2016-04-29','java'),('neha@yahoo.com','29','CE','','','2016-04-29','c'),('neha@yahoo.com','29','CE','','','2016-04-29','c'),('neha@yahoo.com','29','CA','','','2016-04-29','cpp'),('neha@yahoo.com','29','WA','','','2016-04-29','cpp'),('neha@yahoo.com','29','WA','','','2016-04-29','cpp'),('neha@yahoo.com','29','CE','','','2016-04-29','c'),('neha@yahoo.com','29','WA','','','2016-04-29','cpp'),('neha@yahoo.com','29','CA','','','2016-04-29','cpp'),('rahul@morena.com','39','CE','','','2016-04-29','java'),('rahul@morena.com','39','CE','','','2016-04-29','java'),('rahul@morena.com','39','CE','','','2016-04-29','java'),('rahul@morena.com','39','CA','','','2016-04-29','java'),('neha@yahoo.com','29','CE','','','2016-04-29','c'),('neha@yahoo.com','29','CA','','','2016-04-29','c'),('neha@yahoo.com','39','RE','','','2016-04-29','c'),('neha@yahoo.com','39','WA','','','2016-04-29','c'),('neha@yahoo.com','39','CA','','','2016-04-29','c'),('neha@yahoo.com','39','CA','','','2016-04-29','c'),('neha@yahoo.com','39','CA','','','2016-04-29','java'),('neha@yahoo.com','39','CA','','','2016-04-29','c'),('neha@yahoo.com','39','CE','','','2016-04-29','c'),('rashmi@gmail.com','29','CA','','','2016-04-29','c'),('rashmi@gmail.com','39','CE','','','2016-04-29','java'),('rashmi@gmail.com','39','CE','','','2016-04-29','c'),('rashmi@gmail.com','39','CE','','','2016-04-29','c'),('rashmi@gmail.com','39','CA','','','2016-04-29','c'),('rashmi@gmail.com','39','CE','','','2016-04-29','c'),('rashmi@gmail.com','39','CE','','','2016-04-29','java'),('rashmi@gmail.com','39','CE','','','2016-04-29','c'),('rashmi@gmail.com','39','CE','','','2016-04-29','c'),('rashmi@gmail.com','39','CA','','','2016-04-29','c'),('rahul@morena.com','39','CE','','','2016-04-29','java'),('rahul@morena.com','39','CA','','','2016-04-29','cpp'),('Rahul@morena.com','29','CA','','','2016-04-30','cpp'),('Rahul@morena.com','29','CE','','','2016-04-30','cpp'),('rashmi@gmail.com','39','CE','','','2016-04-30','java'),('rashmi@gmail.com','39','CE','','','2016-04-30','cpp'),('rashmi@gmail.com','39','CE','','','2016-04-30','c'),('rashmi@gmail.com','39','CE','','','2016-04-30','c'),('rashmi@gmail.com','39','CA','','','2016-04-30','c'),('rashmi@gmail.com','39','CE','','','2016-04-30','c'),('rashmi@gmail.com','39','CA','','','2016-05-01','c'),('rashmi@gmail.com','39','CE','','','2016-05-01','c'),('rashmi@gmail.com','39','CA','','','2016-05-01','c'),('bandil@komal.com','53','CE','','','2016-05-01','c'),('bandil@komal.com','53','CE','','','2016-05-01','java'),('bandil@komal.com','53','CE','','','2016-05-01','c'),('bandil@komal.com','53','CE','','','2016-05-01','c'),('bandil@komal.com','53','CE','','','2016-05-01','java'),('bandil@komal.com','53','CE','','','2016-05-01','cpp'),('bandil@komal.com','54','CE','','','2016-05-01','c'),('bandil@komal.com','54','WA','','','2016-05-01','c'),('bandil@komal.com','54','WA','','','2016-05-01','c'),('bandil@komal.com','54','WA','','','2016-05-01','c'),('bandil@komal.com','51','WA','','','2016-05-01','c'),('bandil@komal.com','51','WA','','','2016-05-01','c'),('bandil@komal.com','51','WA','','','2016-05-01','c'),('bandil@komal.com','51','WA','','','2016-05-01','c'),('bandil@komal.com','51','WA','','','2016-05-01','c'),('bandil@komal.com','52','WA','','','2016-05-01','c'),('bandil@komal.com','55','WA','','','2016-05-01','c'),('bandil@komal.com','56','CE','','','2016-05-01','java'),('bandil@komal.com','56','WA','','','2016-05-01','c'),('bandil@komal.com','57','WA','','','2016-05-01','c'),('bandil@komal.com','57','WA','','','2016-05-01','c'),('bandil@komal.com','57','WA','','','2016-05-01','c'),('bandil@komal.com','57','WA','','','2016-05-01','c'),('bandil@komal.com','57','WA','','','2016-05-01','c'),('bandil@komal.com','57','CA','','','2016-05-01','c'),('bandil@komal.com','57','CA','','','2016-05-01','c'),('rashmi@gmail.com','36','WA','','','2016-05-18','java'),('rashmi@gmail.com','36','CE','','','2016-05-18','java'),('amitsingh9994@gmail.com','54','CE','','','2016-05-20','java'),('rahul@morena.com','39','CE','','','2016-05-21','c'),('rahul@morena.com','39','CE','','','2016-05-21','c'),('rahul@morena.com','24','WA','','','2016-05-24','cpp'),('rahul@morena.com','24','CA','','','2016-05-24','cpp'),('rahul@morena.com','12','CE','','','2016-05-24','java'),('rahul@morena.com','12','CE','','','2016-05-24','java'),('bandil@komal.com','24','CA','','','2016-05-25','java'),('bandil@komal.com','24','WA','','','2016-05-25','java'),('bandil@komal.com','24','CE','','','2016-05-25','java'),('bandil@komal.com','24','CA','','','2016-05-25','java'),('bandil@komal.com','39','CA','','','2016-05-25','c'),('bandil@komal.com','39','CA','','','2016-05-25','c'),('rahul@morena.com','39','CA','','','2016-05-25','c'),('rahul@morena.com','39','CE','','','2016-05-25','c'),('rahul@morena.com','39','WA','','','2016-05-25','c'),('rahul@morena.com','39','CA','','','2016-05-25','c'),('rahul@morena.com','39','CE','','','2016-05-25','java'),('rahul@morena.com','24','CE','','','2016-05-25','java'),('rahul@morena.com','24','CA','','','2016-05-25','java'),('rahul@morena.com','24','WA','','','2016-05-25','java'),('rahul@morena.com','24','CA','','','2016-05-26','java'),('rahul@morena.com','24','CE','','','2016-05-26','java'),('rahul@morena.com','39','CE','','','2016-05-26','java'),('rahul@morena.com','39','CA','','','2016-05-26','java'),('rahul@morena.com','39','CE','','','2016-05-26','c'),('rahul@morena.com','39','WA','','','2016-05-26','c'),('rahul@morena.com','39','CA','','','2016-05-26','c'),('rashmi@gmail.com','39','CA','','','2016-05-28','java'),('rahul@morena.com','39','CA','','','2016-05-28','java'),('rahul@morena.com','39','CE','','','2016-05-28','java'),('rahul@morena.com','39','WA','','','2016-05-28','java'),('rahul@morena.com','12','WA','','','2016-05-29','java'),('rahul@morena.com','12','WA','','','2016-05-29','java'),('bandil@komal.com','12','CE','','','2016-05-29','java'),('rashmi@gmail.com','39','CA','','','2016-05-30','java'),('rashmi@gmail.com','29','CE','','','2016-05-30','java'),('rashmi@gmail.com','29','RE','','','2016-05-30','java');
/*!40000 ALTER TABLE `Solutions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `userName` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `pic` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES ('Gaurav Sharma','raceison','','/profile/.jpeg'),('g s','bb','a@a.com',NULL),('aa aa','aaa','aa@aaa.aaa',NULL),('Amit Singh','12345678','amit@singh.com',NULL),('Amit Singh','pass','amitsingh9994@gmail.com','/profile/amitsingh9994@gmail.com.jpeg'),('g s','qq','as@a.com',NULL),('g s','qw','as@sa.com',NULL),('g s','ss','ass@a.com',NULL),('Shubham Bandil','pass','bandil@komal.com','/profile/bandil@komal.com.jpeg'),('Dawar','ww','dawar@lol.com',NULL),('Devesh Dubey','emmawatson','deveshdubey73@gmail.com',NULL),('fr','ww','fr@d.com',NULL),('Gaurav Sharma','raceison','gauravsati19@gmail.com','/profile/gauravsati19@gmail.com.jpeg'),('ha','ja','ja@ss',NULL),('ll','ll','ll@ll.ll',NULL),('Mario','princess','Mario@mushroom.com','/home/gaurav/CodeSalad/Users/Mario@mushroom.com/MarioSMBW.png'),('Neha Sharma','password','neha@gmail.com',NULL),('Neha Sharma','vasant','neha@yahoo.com','/profile/neha@yahoo.com.png'),('qq','qq','qq@s.com',NULL),('qwer','sd','qwd@ed.com',NULL),('Rahul Basediya','pass','rahul@morena.com','/profile/rahul@morena.com.png'),('Raju Jadon','raju','raju@raju.raju',NULL),('Rashmi Sharma','pass','rashmi@gmail.com','/profile/rashmi@gmail.com.jpeg'),('rrr','rrr','rrr@rrr',NULL),('SHEETAL SINGH','Sheet@l15','sheetalsngh7@gmail.com','/profile/sheetalsngh7@gmail.com.jpeg'),('Sheetal Singh','pass','sheetalsngh@gmail.com','/profile/sheetalsngh@gmail.com.jpeg');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-07 14:37:00
