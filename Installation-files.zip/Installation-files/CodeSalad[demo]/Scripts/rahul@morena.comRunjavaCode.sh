#!/bin/bash  
javac -Xstdout /home/gaurav/CodeSalad/Users/rahul@morena.com/12error.txt /home/gaurav/CodeSalad/Users/rahul@morena.com/12.java