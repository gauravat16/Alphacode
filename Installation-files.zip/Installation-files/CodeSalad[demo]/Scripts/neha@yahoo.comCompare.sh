#!/bin/bash 
 echo 4 5  | (cd /home/gaurav/CodeSalad/Users/neha@yahoo.com && exec /home/gaurav/CodeSalad/Users/neha@yahoo.com/a.out > /home/gaurav/CodeSalad/Users/neha@yahoo.com/output.txt)