#!/bin/bash  
javac -Xstdout /home/gaurav/CodeSalad/Users/neha@yahoo.com/39error.txt /home/gaurav/CodeSalad/Users/neha@yahoo.com/39.java