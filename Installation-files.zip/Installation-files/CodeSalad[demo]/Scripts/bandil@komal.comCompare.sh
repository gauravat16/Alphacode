#!/bin/bash 
 echo 4 5  | (cd /home/gaurav/CodeSalad/Users/bandil@komal.com && exec /home/gaurav/CodeSalad/Users/bandil@komal.com/a.out > /home/gaurav/CodeSalad/Users/bandil@komal.com/output.txt)