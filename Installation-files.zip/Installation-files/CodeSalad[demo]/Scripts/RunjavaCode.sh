#!/bin/bash  
javac -Xstdout /home/gaurav/CodeSalad/Users/rashmi@gmail.com/12error.txt /home/gaurav/CodeSalad/Users/rashmi@gmail.com/12.java