#!/bin/bash  
(cd /home/gaurav/CodeSalad/Users/rashmi@gmail.com/ && gcc /home/gaurav/CodeSalad/Users/rashmi@gmail.com/39.c 2> /home/gaurav/CodeSalad/Users/rashmi@gmail.com/39error.txt )