#!/bin/bash  
mkdir /home/gaurav/CodeSalad/Users/ad