#!/bin/bash  
javac -Xstdout /home/gaurav/CodeSalad/Users/rashmi@gmail.com/29error.txt /home/gaurav/CodeSalad/Users/rashmi@gmail.com/29.java