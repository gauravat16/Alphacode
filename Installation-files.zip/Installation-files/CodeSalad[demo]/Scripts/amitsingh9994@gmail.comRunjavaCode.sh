#!/bin/bash  
javac -Xstdout /home/gaurav/CodeSalad/Users/amitsingh9994@gmail.com/54error.txt /home/gaurav/CodeSalad/Users/amitsingh9994@gmail.com/54.java