#!/bin/bash 
 echo   | (cd /home/gaurav/CodeSalad/Users/Rahul@morena.com && exec /home/gaurav/CodeSalad/Users/Rahul@morena.com/a.out > /home/gaurav/CodeSalad/Users/Rahul@morena.com/output.txt)