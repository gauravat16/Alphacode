#!/bin/bash  
(cd /home/gaurav/CodeSalad/Users/Rahul@morena.com/ && g++ /home/gaurav/CodeSalad/Users/Rahul@morena.com/29.cpp 2> /home/gaurav/CodeSalad/Users/Rahul@morena.com/29error.txt )