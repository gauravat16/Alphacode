#!/bin/bash  
(cd /home/gaurav/CodeSalad/Users/bandil@komal.com/ && gcc /home/gaurav/CodeSalad/Users/bandil@komal.com/39.c 2> /home/gaurav/CodeSalad/Users/bandil@komal.com/39error.txt )