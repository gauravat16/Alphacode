#!/bin/bash  
(cd /home/gaurav/CodeSalad/Users/rahul@morena.com/ && gcc /home/gaurav/CodeSalad/Users/rahul@morena.com/39.c 2> /home/gaurav/CodeSalad/Users/rahul@morena.com/39error.txt )