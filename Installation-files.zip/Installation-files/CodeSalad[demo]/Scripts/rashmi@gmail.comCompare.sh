#!/bin/bash 
 echo   | java -classpath /home/gaurav/CodeSalad/Users/rashmi@gmail.com Main  > /home/gaurav/CodeSalad/Users/rashmi@gmail.com/output.txt