#!/bin/bash 
 echo 45 24  | java -classpath /home/gaurav/CodeSalad/Users/rahul@morena.com Main  > /home/gaurav/CodeSalad/Users/rahul@morena.com/output.txt