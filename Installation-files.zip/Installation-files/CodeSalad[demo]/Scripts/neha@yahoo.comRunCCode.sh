#!/bin/bash  
(cd /home/gaurav/CodeSalad/Users/neha@yahoo.com/ && gcc /home/gaurav/CodeSalad/Users/neha@yahoo.com/39.c 2> /home/gaurav/CodeSalad/Users/neha@yahoo.com/39error.txt )