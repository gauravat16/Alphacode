#!/bin/bash  
javac -Xstdout /home/gaurav/CodeSalad/Users/bandil@komal.com/12error.txt /home/gaurav/CodeSalad/Users/bandil@komal.com/12.java