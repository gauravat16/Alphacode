#!/bin/bash 
 echo 4   | (cd /home/gaurav/CodeSalad/Users/rashmi@gmail.com && exec /home/gaurav/CodeSalad/Users/rashmi@gmail.com/a.out > /home/gaurav/CodeSalad/Users/rashmi@gmail.com/output.txt)