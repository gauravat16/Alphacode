 #include<stdio.h>
int main()
{
int a,b;


while(1)
 {
   scanf("%d",&a);


      if(a==42)

       {

      break;
       } 
printf("%d ",a);     
   
 }
}