#include<stdio.h>
int main()
{
int a,b;
scanf("%d",&a);
b=a;
while(b!=0)
 {
   
      if(b==42)
       {
       break;
       } 
     
   
 }
}