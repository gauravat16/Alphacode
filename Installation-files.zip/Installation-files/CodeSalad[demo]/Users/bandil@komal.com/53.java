#include<stdio.h>
int main()
{
int a,b;
scanf("%d",&a);
b=a;
while(b!=0)
 {
   if(b%2==0) 
   {
    if(b%3==0)
     {
      if(b%7==0)
       {
       break;
       } 
     }
   }
 }
}
