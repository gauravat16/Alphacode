 #include<stdio.h>
int main()
{
int a,b;


while(1)
 {
   scanf("%d",&a);
printf("%d \n",a);

      if(a==42)

       {


       break;
       } 
     
   
 }
}
