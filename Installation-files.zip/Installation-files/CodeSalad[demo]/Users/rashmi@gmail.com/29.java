  import java.util.Scanner;

class Main {
	
	static void func()
{
	System.out.println("lol");
func();
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	func();


	}

}