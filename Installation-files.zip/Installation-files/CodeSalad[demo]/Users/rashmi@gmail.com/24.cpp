#include<iostream>

using namespace std;

int main()

{

    

cout<<"losl"<<endl;

    return 0;

}
