import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
 class Date {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  
		String time = LocalDate.now().toString();
System.out.println(time);
	}

}
