
import java.util.Scanner;

class Main {
	
	static void func()
	{
	Scanner in = new Scanner(System.in);
	for(int i = 1;i<=2;i++)
	{
		System.out.println(in.next());
	}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		func();

	}

}