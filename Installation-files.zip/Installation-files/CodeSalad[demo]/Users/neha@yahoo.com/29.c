#include<stdio.h>
int main()
{
printf("lol");
return(0);
}