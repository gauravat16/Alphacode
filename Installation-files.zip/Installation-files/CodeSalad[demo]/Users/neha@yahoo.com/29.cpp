   #include<iostream>

using namespace std;

int main()

{

    

cout<<"lol";
 return 0;

}