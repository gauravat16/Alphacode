#!/bin/bash
mkdir CodeSalad
mkdir CodeSalad/Competitions
mkdir CodeSalad/Problems
mkdir CodeSalad/profile
mkdir CodeSalad/Scripts
mkdir CodeSalad/Users

